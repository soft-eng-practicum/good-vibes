<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];

	//check if clawmail exists
	$clawmailcheckquery = "SELECT clawmail, password, salt, readAgreement, isBanned FROM Player WHERE clawmail = '".$clawmail."';";

	$clawmailcheck = mysqli_query($conn, $clawmailcheckquery); //error code #2 = clawmail check query failed
	if (mysqli_num_rows($clawmailcheck) != 1)
		echo "Either no user with clawmail, or more than one.";
	
	$getcredentials = mysqli_fetch_assoc($clawmailcheck);
	$existingsalt = $getcredentials["salt"];
	$existinghash = $getcredentials["password"];
	$readAgreement = $getcredentials["readAgreement"];
	$isBanned = $getcredentials["isBanned"];

	echo "0ツ".$existingsalt."ツ".$existinghash."ツ".$readAgreement."ツ".$isBanned;
?>