<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];
	$subject = $_REQUEST['subject'];
	$message = $_REQUEST['message'];

	$getidquery = "SELECT idPlayer FROM Player WHERE clawmail = '".$clawmail."';";
	$resultidcheck = mysqli_query($conn, $getidquery);
	$getplayerid = mysqli_fetch_assoc($resultidcheck);
	$playerid = $getplayerid["idPlayer"];

	/*$joinquery = "Select * FROM Vibe vibe INNER JOIN Player player ON vibe.idPlayer = player.idPlayer WHERE player.clawmail = '".$clawmail."';";
	$joinquerycheck = mysqli_query($conn, $joinquery);
	$getdata = mysqli_fetch_assoc($resultcheck);*/

	$inserttopicquery = "INSERT INTO Vibe (idPlayer, subject, message, vibeType) VALUES ('".$playerid."', '".$subject."', '".$message."', 'topic');";

	mysqli_query($conn, $inserttopicquery);
	echo "0";
?>