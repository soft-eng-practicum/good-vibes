<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];

	//check if clawmail exists
	$updateagreementquery = "UPDATE Player SET readAgreement = 'yes' WHERE clawmail = '".$clawmail."';";

	mysqli_query($conn, $updateagreementquery); //error code #2 = clawmail check query failed
	echo "0";
?>