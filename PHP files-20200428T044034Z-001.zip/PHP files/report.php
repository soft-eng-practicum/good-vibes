<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];
	$vibeid = $_REQUEST['messageID'];
	$reportcategory = $_REQUEST['reportCategory'];

	$getdataquery = "SELECT idPlayer FROM Vibe WHERE idVibe = '".$vibeid."';";
	$resultcheck = mysqli_query($conn, $getdataquery);
	$getplayerid = mysqli_fetch_assoc($resultcheck);
	$playerid = $getplayerid["idPlayer"];

	$vibetypequery = "SELECT vibeType FROM Vibe WHERE idVibe = '".$vibeid."';";
	$vtqresult = mysqli_query($conn, $vibetypequery);
	$getvibetype = mysqli_fetch_assoc($vtqresult);
	$vibetype = $getvibetype["vibeType"];

	if ($vibetype == "topic")
	{
		$reportnumberupdatequery = "UPDATE Vibe SET timesReported = timesReported + '1' WHERE idVibe = '".$vibeid."';";
		mysqli_query($conn, $reportnumberupdatequery);

		$concatstring = ', '.$reportcategory;
		$reportcategoryupdatequery = "UPDATE Vibe SET reportCategory = CASE WHEN reportCategory IS NULL THEN '".$reportcategory."' ELSE CONCAT(reportcategory, '".$concatstring."') END WHERE idVibe = '".$vibeid."';";
		mysqli_query($conn, $reportcategoryupdatequery);

		$checktimesreportedquery = "SELECT timesReported FROM Vibe WHERE idVibe = '".$vibeid."';";
		$ctrresult = mysqli_query($conn, $checktimesreportedquery);
		$gettimesreported = mysqli_fetch_assoc($ctrresult);
		$timesReported = $gettimesreported["timesReported"];

		if ($timesReported >= 3)
		{
			$isvisibleupdatequery = "UPDATE Vibe SET isVisible = 'no' WHERE idVibe = '".$vibeid."';";
			mysqli_query($conn, $isvisibleupdatequery);
		}
	}
	else if ($vibetype == "reply")
	{
		$reportnumberupdatequery = "UPDATE Vibe SET timesReported = timesReported + '1' WHERE idVibe = '".$vibeid."';";
		mysqli_query($conn, $reportnumberupdatequery);

		$concatstring = ', '.$reportcategory;
		$reportcategoryupdatequery = "UPDATE Vibe SET reportCategory = CASE WHEN reportCategory IS NULL THEN '".$reportcategory."' ELSE CONCAT(reportcategory, '".$concatstring."') END WHERE idVibe = '".$vibeid."';";
		mysqli_query($conn, $reportcategoryupdatequery);

		$isvisibleupdatequery = "UPDATE Vibe SET isVisible = 'no' WHERE idVibe = '".$vibeid."';";
		mysqli_query($conn, $isvisibleupdatequery);
	}

	$playerbanquery = "SELECT * FROM Vibe WHERE idPlayer = '".$playerid."' AND isVisible = 'no';";
	$pbresult = mysqli_query($conn, $playerbanquery);
	//$getbannedvibes = mysqli_fetch_assoc($pbresult);
	if (mysqli_num_rows($pbresult) >= 7)
	{
		$playerbannedquery = "UPDATE Player SET isBanned = 'yes' WHERE idPlayer = '".$playerid."';";
		mysqli_query($conn, $playerbannedquery);
	}

	echo "0".$reportcategory;
?>