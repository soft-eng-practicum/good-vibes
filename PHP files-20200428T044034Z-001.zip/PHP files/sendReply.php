<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$reply = $_REQUEST['reply'];
	$clawmail = $_REQUEST['clawmail'];
	$id = $_REQUEST['messageID'];

		//check if clawmail exists
	$UserIdQuery = "SELECT idPlayer FROM Player WHERE clawmail = '".$clawmail."';";

	$getUserId = mysqli_query($conn, $UserIdQuery);
	/*if (mysqli_num_rows($getUserId) > 0)
	{
		echo "3: User exists"; //error code #3 - clawmail exists cannot register
	}*/
	$getcredentials = mysqli_fetch_assoc($getUserId);
	$PlayerID = $getcredentials["idPlayer"];
	//echo "playerID received: ".$PlayerID;

	$MessageInfoQuery = "SELECT idVibe, subject FROM Vibe WHERE idVibe = '".$id."';";

	$getMessageInfo = mysqli_query($conn, $MessageInfoQuery); 
	if (mysqli_num_rows($getMessageInfo) != 1)
	{
		echo "4: Topic vibe exists"; //error code #3 - clawmail exists cannot register
	}

	//$id = $getUserId["idPlayer"];
	$getMessageData = mysqli_fetch_assoc($getMessageInfo);
	$idVibe = $getMessageData["idVibe"];
	$subject = $getMessageData["subject"];

	//adds message to table
	$insertuserquery = "INSERT INTO Vibe (idPlayer, subject, message, vibeType, vibeTopic) VALUES ('".$PlayerID."', '".$subject."', '".$reply."', 'reply', '".$idVibe."');";
	//$insertuserquery = "INSERT INTO Vibe (idPlayer, isVisible, subject, message, timesReported, vibeType, vibeTopic, userClosed) VALUES ('6', 'yes', 'lel', 'lel2', '420', 'reply', '1', 'no');";
	mysqli_query($conn, $insertuserquery); //error code #4 - insert query failed

	echo "0";

?>