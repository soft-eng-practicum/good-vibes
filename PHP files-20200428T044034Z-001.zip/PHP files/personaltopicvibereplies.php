<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$idvibe = $_REQUEST['idVibe'];

	$joinquery = "Select vibe.message, player.userType, vibe.idVibe FROM Vibe vibe INNER JOIN Player player ON vibe.idPlayer = player.idPlayer WHERE vibe.isVisible = 'yes' AND vibe.vibeTopic = '".$idvibe."';";
	$joinquerycheck = mysqli_query($conn, $joinquery);

	/*$getmsgquery = "SELECT message FROM Vibe WHERE vibeTopic = '".$idvibe."' AND vibeType = 'reply';";
	$msgresultcheck = mysqli_query($conn, $getmsgquery);
	$getmsg = mysqli_fetch_assoc($msgresultcheck);
	$msg = $getmsg["message"];*/

	//$getdataquery = "SELECT * FROM SentPersonalTopicVibes WHERE idPlayer = '".$playerid."';";

	//$result = mysqli_query($conn, $viewcheck);
	while ($row = mysqli_fetch_assoc($joinquerycheck))
	{
		foreach ($row as $key=>$value)
		{
			echo $value.":";
		}
		echo "ãƒ„";
	}
?>