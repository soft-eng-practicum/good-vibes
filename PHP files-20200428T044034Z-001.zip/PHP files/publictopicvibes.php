<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];

	$getidquery = "SELECT idPlayer FROM Player WHERE clawmail = '".$clawmail."';";
	$resultidcheck = mysqli_query($conn, $getidquery);
	$getplayerid = mysqli_fetch_assoc($resultidcheck);
	$playerid = $getplayerid["idPlayer"];

	$viewcheck = "SELECT * FROM PublicTopicVibes;";

	//$result = $conn->query($viewcheck);

	//unrestricted
	/*$result = mysqli_query($conn, $viewcheck);
	while ($row = mysqli_fetch_assoc($result))
	{
		foreach ($row as $key=>$value)
		{
			echo $value.":";
		}
		echo "ãƒ„";
	}*/
	//restricted
	$result = mysqli_query($conn, $viewcheck);
	while ($row = mysqli_fetch_assoc($result))
	{
		$rows[] = $row;
	}
	for ($i = 0; $i < count($rows); $i++)
	{
		for ($k = 0; $k < 3; $k++)
		{
			$skip = true;
			if ($k == 0)
				$n = 'subject';
			else if ($k == 1)
				$n = 'message';
			else if ($k == 2)
				$n = 'idVibe';

			$pastreplycheck = "SELECT * FROM ReplyVibes WHERE idPlayer = '".$playerid."' AND vibeTopic = '".$rows[$i]['idVibe']."';";
			$resultreplycheck = mysqli_query($conn, $pastreplycheck);
			$publictopicvibeidcheck = "SELECT * FROM Vibe WHERE idVibe = '".$rows[$i]['idVibe']."' AND idPlayer = '".$playerid."';";
			$resultvibeidcheck = mysqli_query($conn, $publictopicvibeidcheck);
			if (mysqli_num_rows($resultreplycheck) > 0 || mysqli_num_rows($resultvibeidcheck) > 0) //vibe user already replied to or vibe user made
			{
				$skip = true;
				//echo "skip is ".(int)$skip." and shouldnt print ".$i;
				$k = 3;
			}
			else
				$skip = false;
			if (!$skip)
				echo $rows[$i][$n].":";
		}
		if (!$skip)
			echo "ãƒ„";
	}

	//$results = array();

	/*if ($result->num_rows > 0)
	{
		echo "0/";
		foreach ($row = $result->fetch_assoc())
		{
			//array_push($results, $row);
			foreach ($row as $)
			{
				echo $info.":";
			}
			echo $row."/";
		}
	}*/
	/*if ($result->num_rows > 0)
	{
		for ($row = 0; $row < count($result); $row++)
		{
			for ($col = 0; $col < count($result[$row]); $row++)
			{
				echo $result[$row][$col].":";
			}
			echo "/";
		}
	}*/

	//echo implode("/", $results);
?>