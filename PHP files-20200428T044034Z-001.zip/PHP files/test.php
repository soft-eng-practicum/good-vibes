<?php
	echo "connected to test.php";
?>