<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];
	$hash = $_REQUEST['hash'];
	$salt = $_REQUEST['salt'];
	$userType = $_REQUEST['userType'];

	//check if clawmail exists
	$clawmailcheckquery = "SELECT clawmail FROM Player WHERE clawmail = '".$clawmail."';";

	$clawmailcheck = mysqli_query($conn, $clawmailcheckquery); //error code #2 = clawmail check query failed
	if (mysqli_num_rows($clawmailcheck) > 0)
		echo "User already registered";

	//add user to the table
	$insertuserquery = "INSERT INTO Player (clawmail, password, salt, userType) VALUES ('".$clawmail."', '".$hash."', '".$salt."', '".$userType."');";
	mysqli_query($conn, $insertuserquery); //error code #4 - insert query failed

	echo "0";
?>