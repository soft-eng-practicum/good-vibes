<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	ini_set('log_errors', 1);

	$conn = mysqli_connect('', '', '', ''); //url to db or localhost, db username, db password, database name

	$clawmail = $_REQUEST['clawmail'];

	$getdataquery = "SELECT idPlayer FROM Player WHERE clawmail = '".$clawmail."';";
	$resultcheck = mysqli_query($conn, $getdataquery);
	$getplayerid = mysqli_fetch_assoc($resultcheck);
	$playerid = $getplayerid["idPlayer"];

	$viewcheck = "SELECT * FROM SentPersonalTopicVibes WHERE idPlayer = '".$playerid."' ORDER BY 1 DESC;";

	$result = mysqli_query($conn, $viewcheck);
	while ($row = mysqli_fetch_assoc($result))
	{
		foreach ($row as $key=>$value)
		{
			echo $value.":";
		}
		echo "ãƒ„";
	}
?>